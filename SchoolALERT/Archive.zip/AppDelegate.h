//
//  AppDelegate.h
//  SchoolALERT
//
//  Created by Helix Group on 9/16/14.
//  Copyright (c) 2014 christopher@helixgroup.net. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
